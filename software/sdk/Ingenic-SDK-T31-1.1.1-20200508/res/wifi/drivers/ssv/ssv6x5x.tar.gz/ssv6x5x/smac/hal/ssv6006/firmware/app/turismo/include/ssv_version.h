#ifndef _SSV_VERSION_H_
#define _SSV_VERSION_H_

static u32 ssv_firmware_version = 9635;

#define SSV_FIRMWARE_URl "http://192.168.15.30/svn/software/wifi/trunk/CABRIO-E/host_drivers/Linux/ssv6xxx/smac/firmware"
#define COMPILERHOST "ssv-Latitude-E6440"
#define COMPILERDATE "12-08-2015-13:32:41"
#define COMPILEROS "linux"
#define COMPILEROSARCH "x86_64-linux-gnu-thread-multi"

#endif

