#ifndef _DRV_PHY_H_
#define _DRV_PHY_H_

void drv_phy_init(void);
void drv_phy_off(void);
void drv_phy_on(void);
void drv_phy_b_only(void);
void drv_phy_bgn(void);
#endif /* _DRV_PHY_H_ */

