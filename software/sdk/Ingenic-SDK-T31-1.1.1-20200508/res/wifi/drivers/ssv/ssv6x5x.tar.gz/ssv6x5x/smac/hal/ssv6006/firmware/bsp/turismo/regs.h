#ifndef __REGS_H__
#define __REGS_H__
#include "turismo_regs.h"
#include "ssv_regs.h"
#endif
