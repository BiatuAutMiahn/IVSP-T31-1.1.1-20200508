#ifndef _MAC_MONITOR_H_
#define _MAC_MONITOR_H_

s32 mac_monitor_init();
void mac_monitor_start(u32 monitorTime,u8 mode);
void mac_monitor_stop();


#endif /* _CLI_CMD_H_ */
