#ifndef __BSP_DEFS_H__
#define __BSP_DEFS_H__

#include "turismo_defs.h"

#endif // __BSP_DESF_H__
