
/*
 * App config
 */
#define CONFIG_MINIMAL_STACK_SIZE 0x100
