#ifndef _DRV_EFUSEE_H_
#define _DRV_EFUSEE_H_

void read_efuse_identify(u32 *chip_identity);

#endif /* _DRV_EFUSEE_H_ */

