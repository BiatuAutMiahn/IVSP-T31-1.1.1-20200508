#ifndef _SSV_FRIMWARE_VERSION_H_
#define _SSV_FRIMWARE_VERSION_H_

static u32 ssv_firmware_version = 17074;

#define SSV_FIRMWARE_URl "http://192.168.15.30/svn/software/wifi/trunk/CABRIO-E/host_drivers/Linux/ssv6xxx/smac/hal/ssv6006/firmware"
#define FRIMWARE_COMPILERHOST "willlu-Latitude-E5440"
#define FRIMWARE_COMPILERDATE "03-14-2018-18:28:29"
#define FRIMWARE_COMPILEROS "linux"
#define FRIMWARE_COMPILEROSARCH "x86_64-linux-gnu-thread-multi"

#endif

