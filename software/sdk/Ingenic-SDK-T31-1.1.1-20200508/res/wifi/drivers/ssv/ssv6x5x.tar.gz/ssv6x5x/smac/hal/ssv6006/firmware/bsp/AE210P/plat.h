#ifndef __PLAT_H__
#define __PLAT_H__

#define IRQ_SYS_TICK_VECTOR IRQ_PIT_VECTOR
#define IRQ_SYS_TICK2_VECTOR IRQ_PIT_VECTOR


#endif
