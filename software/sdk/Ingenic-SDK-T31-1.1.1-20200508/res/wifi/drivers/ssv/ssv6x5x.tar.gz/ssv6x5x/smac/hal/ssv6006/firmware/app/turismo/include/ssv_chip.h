#ifndef _SSV_CHIP_H_
#define _SSV_CHIP_H_

#define CHIP_IDENTITY 0x00000000

#endif

