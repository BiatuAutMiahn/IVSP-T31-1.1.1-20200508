#!/bin/bash

./ver_info.pl include/ssv_version.h

