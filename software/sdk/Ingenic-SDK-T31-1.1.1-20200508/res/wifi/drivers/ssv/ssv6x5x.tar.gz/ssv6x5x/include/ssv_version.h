#ifndef _SSV_VERSION_H_
#define _SSV_VERSION_H_

static u32 ssv_root_version = 17126;

#define SSV_ROOT_URl "http://192.168.15.30/svn/software/wifi/tag/smac-release-tag/SMAC.0000.1807.04/ssv6x5x"
#define COMPILERHOST "ssv-ThinkPad-X230"
#define COMPILERDATE "03-20-2018-16:02:57"
#define COMPILEROS "linux"
#define COMPILEROSARCH "x86_64-linux-gnu-thread-multi"

#endif

