#/bin/bash
tail -f /var/log/kern.log
