#ifndef __BSP_REGS_H__
#define __BSP_REGS_H__
#include "turismo_regs.h"
#endif
