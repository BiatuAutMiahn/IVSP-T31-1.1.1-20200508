#ifndef __STDDEF_H__
#define __STDDEF_H__

typedef unsigned long size_t;
#endif /* __STDDEF_H__ */
