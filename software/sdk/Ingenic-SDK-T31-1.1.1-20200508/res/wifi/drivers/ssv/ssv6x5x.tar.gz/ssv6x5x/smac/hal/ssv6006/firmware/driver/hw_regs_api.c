
#include <config.h>
#include <types.h>
#include "hw_regs_api.h"
#include <regs.h>



ETHER_ADDR gSTA_MAC;
ETHER_ADDR gBSSID;


u32 __HWREG_Init(void)
{

	return TRUE;
}

